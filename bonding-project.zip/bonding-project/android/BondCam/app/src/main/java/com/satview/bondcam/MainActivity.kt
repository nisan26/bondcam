package com.satview.bondcam

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.SurfaceHolder
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.common.VideoCodec
import com.pedro.library.srt.SrtCamera2
import com.pedro.library.view.OpenGlView
import com.satview.bondcam.srtla.BondingNetworks
import com.satview.bondcam.srtla.SrtlaSender

class MainActivity : AppCompatActivity(), ConnectChecker, SurfaceHolder.Callback {

    companion object {
        private const val LOCAL_SRT_PORT = 6000
        private const val DIRECT_PORT = 8890
    }

    private lateinit var openGlView: OpenGlView
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView
    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var etBitrate: EditText
    private lateinit var etStreamId: EditText

    private var camera: SrtCamera2? = null
    private var sender: SrtlaSender? = null
    private var networks: BondingNetworks? = null
    private var streaming = false
    @Volatile private var srtStarted = false

    private val ui = Handler(Looper.getMainLooper())
    private val statusTicker = object : Runnable {
        override fun run() {
            sender?.let { tvStatus.text = it.statusLine() }
            ui.postDelayed(this, 1000)
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val cam = grants[Manifest.permission.CAMERA] ?: false
            val mic = grants[Manifest.permission.RECORD_AUDIO] ?: false
            if (cam && mic) initCamera()
            else Toast.makeText(this, "חייבים הרשאת מצלמה ומיקרופון", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        openGlView = findViewById(R.id.openGlView)
        btnStart = findViewById(R.id.btnStart)
        tvStatus = findViewById(R.id.tvStatus)
        etHost = findViewById(R.id.etHost)
        etPort = findViewById(R.id.etPort)
        etBitrate = findViewById(R.id.etBitrate)
        etStreamId = findViewById(R.id.etStreamId)

        openGlView.holder.addCallback(this)
        btnStart.setOnClickListener { if (streaming) stopAll() else startAll() }

        if (hasPermissions()) initCamera()
        else permissionLauncher.launch(neededPermissions())
    }

    private fun neededPermissions(): Array<String> {
        val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        return list.toTypedArray()
    }

    private fun hasPermissions() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun initCamera() {
        if (camera == null) camera = SrtCamera2(openGlView, this)
    }

    private fun startAll() {
        val cam = camera ?: return
        val host = etHost.text.toString().trim()
        val port = etPort.text.toString().trim().toIntOrNull() ?: DIRECT_PORT
        val bitrateKbps = etBitrate.text.toString().trim().toIntOrNull() ?: 3500
        val streamId = etStreamId.text.toString().trim().ifEmpty { "publish:live" }

        // H265 (HEVC): ~40% better compression than H264 at the same quality
        try { cam.setVideoCodec(VideoCodec.H265) } catch (e: Exception) {}

        val ok = cam.prepareVideo(1920, 1080, 30, bitrateKbps * 1000, 2, 0) &&
                 cam.prepareAudio(160 * 1000, 48000, true)
        if (!ok) {
            Toast.makeText(this, "המכשיר לא תומך בהגדרות הקידוד", Toast.LENGTH_LONG).show()
            return
        }

        // DIRECT mode: RootEncoder straight to MediaMTX (no bonding). Default.
        if (port == DIRECT_PORT) {
            streaming = true
            srtStarted = true
            btnStart.text = getString(R.string.stop)
            setInputsEnabled(false)
            tvStatus.text = "מתחבר..."
            StreamService.start(this)
            cam.streamClient.setReTries(1000)
            cam.startStream("srt://$host:$port?streamid=$streamId")
            return
        }

        // BONDING mode (SRTLA) on port 5000.
        sender = SrtlaSender(LOCAL_SRT_PORT, host, port) { msg ->
            runOnUiThread { if (!srtStarted) tvStatus.text = msg }
        }.also { it.start() }

        networks = BondingNetworks(this) { name, network, available ->
            if (available) sender?.addNetwork(name, network)
            else sender?.removeNetwork(name)
        }.also { it.start() }

        streaming = true
        srtStarted = false
        btnStart.text = getString(R.string.stop)
        setInputsEnabled(false)
        tvStatus.text = "ממתין לבונדינג..."
        StreamService.start(this)

        val startedAt = System.currentTimeMillis()
        val waiter = object : Runnable {
            override fun run() {
                if (!streaming) return
                val ready = (sender?.registeredCount() ?: 0) > 0
                val timedOut = System.currentTimeMillis() - startedAt > 20000
                if (ready || timedOut) {
                    srtStarted = true
                    cam.streamClient.setReTries(1000)
                    cam.startStream("srt://127.0.0.1:$LOCAL_SRT_PORT?streamid=$streamId")
                    ui.post(statusTicker)
                } else {
                    ui.postDelayed(this, 300)
                }
            }
        }
        ui.postDelayed(waiter, 800)
    }

    private fun stopAll() {
        ui.removeCallbacks(statusTicker)
        try { camera?.stopStream() } catch (e: Exception) {}
        networks?.stop(); networks = null
        sender?.stop(); sender = null
        streaming = false
        srtStarted = false
        StreamService.stop(this)
        btnStart.text = getString(R.string.start)
        setInputsEnabled(true)
        tvStatus.text = "נעצר"
    }

    private fun setInputsEnabled(enabled: Boolean) {
        etHost.isEnabled = enabled
        etPort.isEnabled = enabled
        etBitrate.isEnabled = enabled
        etStreamId.isEnabled = enabled
    }

    override fun surfaceCreated(holder: SurfaceHolder) {}

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (!hasPermissions()) return
        initCamera()
        val cam = camera ?: return
        if (streaming) {
            // Returning to foreground while streaming: reattach the preview view.
            try { cam.replaceView(openGlView) } catch (e: Exception) {}
        } else {
            if (!cam.isOnPreview) cam.startPreview()
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        val cam = camera ?: return
        if (streaming) {
            // Backgrounded / screen off while streaming: keep encoding headless.
            try { cam.replaceView(applicationContext) } catch (e: Exception) {}
        } else {
            if (cam.isOnPreview) cam.stopPreview()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // App fully closed -> stop everything (camera/mic released here only).
        if (streaming) stopAll()
    }

    override fun onConnectionStarted(url: String) {}

    override fun onConnectionSuccess() {
        runOnUiThread {
            tvStatus.text = "SRT מחובר - משדרים!"
            Toast.makeText(this, "SRT מחובר - משדרים!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onConnectionFailed(reason: String) {
        runOnUiThread { tvStatus.text = "שגיאת חיבור: $reason" }
        camera?.streamClient?.reTry(3000, reason, null)
    }

    override fun onNewBitrate(bitrate: Long) {}

    override fun onDisconnect() {
        runOnUiThread { tvStatus.text = "SRT מנותק" }
    }

    override fun onAuthError() {}
    override fun onAuthSuccess() {}
}
