package com.satview.bondcam.srtla

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest

/**
 * מחזיק את שתי הרשתות פעילות במקביל.
 * בדרך כלל אנדרואיד מכבה את הסלולר כשיש WiFi - requestNetwork עם
 * TRANSPORT_CELLULAR מכריח את המערכת להשאיר אותו דלוק.
 */
class BondingNetworks(
    context: Context,
    private val onChange: (name: String, network: Network?, available: Boolean) -> Unit
) {
    private val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val callbacks = mutableListOf<ConnectivityManager.NetworkCallback>()

    fun start() {
        request("WIFI", NetworkCapabilities.TRANSPORT_WIFI)
        request("CELLULAR", NetworkCapabilities.TRANSPORT_CELLULAR)
    }

    private fun request(name: String, transport: Int) {
        val req = NetworkRequest.Builder()
            .addTransportType(transport)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = onChange(name, network, true)
            override fun onLost(network: Network) = onChange(name, null, false)
        }
        callbacks.add(cb)
        try {
            cm.requestNetwork(req, cb)
        } catch (_: Exception) {
            // אין הרשאה / אין רשת כזו - ממשיכים עם מה שיש
        }
    }

    fun stop() {
        for (cb in callbacks) {
            try { cm.unregisterNetworkCallback(cb) } catch (_: Exception) {}
        }
        callbacks.clear()
    }
}
