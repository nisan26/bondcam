package com.satview.bondcam.srtla

/**
 * קבועי פרוטוקול SRTLA (תואם ל-srtla_rec של BELABOX).
 * SRTLA עוטף חבילות SRT ומפצל אותן על כמה חיבורי UDP (סלולר + WiFi).
 */
object SrtlaProto {
    const val ID_LEN = 256
    const val MTU = 1500

    // סוגי חבילות SRTLA (2 בתים ראשונים, big-endian)
    const val TYPE_KEEPALIVE = 0x9000
    const val TYPE_ACK = 0x9100
    const val TYPE_REG1 = 0x9200
    const val TYPE_REG2 = 0x9201
    const val TYPE_REG3 = 0x9202
    const val TYPE_REG_ERR = 0x9210
    const val TYPE_REG_NGP = 0x9211
    const val TYPE_REG_NAK = 0x9212

    // סוגי חבילות בקרה של SRT (עוברות דרכנו)
    const val SRT_TYPE_ACK = 0x8002
    const val SRT_TYPE_NAK = 0x8003

    // ניהול חלון שליחה לכל חיבור (יחידות כמו ב-srtla המקורי, mult=1000)
    const val WINDOW_MIN = 1 * 1000
    const val WINDOW_DEF = 20 * 1000
    const val WINDOW_MAX = 60 * 1000
    const val WINDOW_INCR = 30
    const val WINDOW_DECR = 100

    const val CONN_TIMEOUT_MS = 4500L
    const val KEEPALIVE_INTERVAL_MS = 1000L
    const val REG_RETRY_MS = 1000L

    fun packetType(buf: ByteArray, len: Int): Int {
        if (len < 2) return -1
        return ((buf[0].toInt() and 0xFF) shl 8) or (buf[1].toInt() and 0xFF)
    }

    /** חבילת SRT-data מזוהה לפי ביט עליון כבוי בבית הראשון */
    fun isSrtData(buf: ByteArray, len: Int): Boolean =
        len >= 16 && (buf[0].toInt() and 0x80) == 0

    /** מספר סידורי (31 ביט) של חבילת דאטה */
    fun dataSeq(buf: ByteArray): Int =
        ((buf[0].toInt() and 0x7F) shl 24) or
        ((buf[1].toInt() and 0xFF) shl 16) or
        ((buf[2].toInt() and 0xFF) shl 8) or
        (buf[3].toInt() and 0xFF)

    fun int32At(buf: ByteArray, off: Int): Int =
        ((buf[off].toInt() and 0xFF) shl 24) or
        ((buf[off + 1].toInt() and 0xFF) shl 16) or
        ((buf[off + 2].toInt() and 0xFF) shl 8) or
        (buf[off + 3].toInt() and 0xFF)

    /** האם seq a קטן מ-b בחשבון מעגלי של 31 ביט */
    fun seqBefore(a: Int, b: Int): Boolean {
        val d = (b - a) and 0x7FFFFFFF
        return d != 0 && d < 0x40000000
    }

    fun buildControl(type: Int, payload: ByteArray? = null): ByteArray {
        val len = 2 + (payload?.size ?: 0)
        val pkt = ByteArray(len)
        pkt[0] = ((type shr 8) and 0xFF).toByte()
        pkt[1] = (type and 0xFF).toByte()
        payload?.copyInto(pkt, 2)
        return pkt
    }
}
