package com.satview.bondcam.srtla

import android.net.Network
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress

/**
 * חיבור UDP יחיד לשרת, כבול לרשת ספציפית (WiFi או סלולר).
 */
class SrtlaConnection(
    val name: String,                    // "WIFI" / "CELLULAR"
    network: Network?,
    private val remote: InetSocketAddress
) {
    val socket: DatagramSocket = DatagramSocket(null).apply {
        reuseAddress = true
        bind(InetSocketAddress(0))
    }

    init {
        // הקסם: כבילת הסוקט לרשת מסוימת - כך סלולר ו-WiFi עובדים במקביל
        network?.bindSocket(socket)
    }

    @Volatile var registered = false
    @Volatile var lastReceivedMs = System.currentTimeMillis()
    @Volatile var lastKeepaliveMs = 0L
    @Volatile var lastRegSentMs = 0L
    @Volatile var closed = false

    // מוגנים ע"י ה-lock של SrtlaSender:
    var window = SrtlaProto.WINDOW_DEF
    val inFlight = HashSet<Int>()

    var sentPackets = 0L
        private set

    fun send(buf: ByteArray, len: Int) {
        if (closed) return
        try {
            socket.send(DatagramPacket(buf, len, remote))
            sentPackets++
        } catch (_: Exception) { /* הרשת נפלה - housekeeping יטפל */ }
    }

    /** ציון לבחירת החיבור הטוב ביותר לחבילה הבאה */
    fun score(): Int = if (!registered || closed) -1 else window / (inFlight.size + 1)

    fun close() {
        closed = true
        registered = false
        try { socket.close() } catch (_: Exception) {}
    }
}
