#!/usr/bin/env bash
# =============================================================
# BondCam server upgrade: multi-camera + recording + playback
# + password-protected control-room dashboard (nginx).
# Run:  sudo bash install-server.sh
# =============================================================
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "צריך sudo"; exit 1; }

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
ADMIN_PORT=8080          # dashboard port (http). SSL adds 443 later.
SRT_PORT=8890

echo "== מתקין תלויות (nginx, htpasswd, ffmpeg) =="
apt-get update
apt-get install -y nginx apache2-utils ffmpeg curl tar

echo "== מעדכן הגדרות MediaMTX =="
mkdir -p /opt/mediamtx /var/recordings /var/www/bondcam-admin
# install MediaMTX if missing
if [ ! -x /opt/mediamtx/mediamtx ]; then
  ARCH=amd64; [ "$(uname -m)" = "aarch64" ] && ARCH=arm64
  VER=$(curl -fsSLI -o /dev/null -w '%{url_effective}' https://github.com/bluenviron/mediamtx/releases/latest | sed 's#.*/##')
  curl -fsSL -o /tmp/mtx.tar.gz "https://github.com/bluenviron/mediamtx/releases/download/${VER}/mediamtx_${VER}_linux_${ARCH}.tar.gz"
  tar -xzf /tmp/mtx.tar.gz -C /opt/mediamtx
fi
cp "$SCRIPT_DIR/mediamtx.yml" /opt/mediamtx/mediamtx.yml

# systemd service for MediaMTX (create if missing)
if [ ! -f /etc/systemd/system/mediamtx.service ]; then
cat > /etc/systemd/system/mediamtx.service <<EOF
[Unit]
Description=MediaMTX media server
After=network-online.target
Wants=network-online.target
[Service]
ExecStart=/opt/mediamtx/mediamtx /opt/mediamtx/mediamtx.yml
Restart=always
RestartSec=2
[Install]
WantedBy=multi-user.target
EOF
fi
# srtla/bonding-relay not needed for direct SRT publishing - stop if present
systemctl stop bonding-relay 2>/dev/null || true
systemctl disable bonding-relay 2>/dev/null || true
systemctl daemon-reload
systemctl enable --now mediamtx.service
systemctl restart mediamtx.service

echo "== מתקין דף חדר הבקרה =="
cp "$SCRIPT_DIR/admin/index.html" /var/www/bondcam-admin/index.html

echo "== מגדיר סיסמת ניהול =="
read -rp "בחר שם משתמש לניהול [admin]: " ADMIN_USER
ADMIN_USER=${ADMIN_USER:-admin}
read -rsp "בחר סיסמה לניהול: " ADMIN_PASS; echo
htpasswd -bc /etc/nginx/.bondcam-htpasswd "$ADMIN_USER" "$ADMIN_PASS"

echo "== מגדיר nginx =="
cat > /etc/nginx/sites-available/bondcam <<EOF
server {
    listen ${ADMIN_PORT};
    server_name _;

    auth_basic "BondCam Control Room";
    auth_basic_user_file /etc/nginx/.bondcam-htpasswd;

    root /var/www/bondcam-admin;
    index index.html;

    location / { try_files \$uri \$uri/ =404; }

    # MediaMTX management API (list of live cameras)
    location /api/ {
        proxy_pass http://127.0.0.1:9997/;
    }
    # HLS playback of live cameras
    location /hls/ {
        proxy_pass http://127.0.0.1:8888/;
        proxy_buffering off;
    }
    # Browse & download recordings
    location /recordings/ {
        alias /var/recordings/;
        autoindex on;
    }
}
EOF
ln -sf /etc/nginx/sites-available/bondcam /etc/nginx/sites-enabled/bondcam
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx

echo "== חומת אש =="
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow ${ADMIN_PORT}/tcp; ufw allow ${SRT_PORT}/udp; ufw allow 80/tcp; ufw allow 443/tcp
fi

IP_NOTE="ודא שהפורטים ${ADMIN_PORT}/tcp ו-${SRT_PORT}/udp פתוחים אצל ספק ה-VPS"
echo ""
echo "==================================================="
echo "  הותקן בהצלחה!"
echo "  חדר בקרה:   http://satview.ddns.net:${ADMIN_PORT}/   (משתמש: ${ADMIN_USER})"
echo "  שידור מטלפון: srt://satview.ddns.net:${SRT_PORT}  streamid: publish:cam1 (או cam2, cam3...)"
echo "  צפייה ב-VLC:  srt://satview.ddns.net:${SRT_PORT}?streamid=read:cam1"
echo "  הקלטות:      http://satview.ddns.net:${ADMIN_PORT}/recordings/"
echo "  ל-SSL (HTTPS): sudo bash setup-ssl.sh"
echo "  $IP_NOTE"
echo "==================================================="
