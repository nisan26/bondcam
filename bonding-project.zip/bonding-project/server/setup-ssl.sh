#!/usr/bin/env bash
# HTTPS for the control room via Let's Encrypt (free cert).
# Requires port 80 open to the internet on satview.ddns.net.
# Run:  sudo bash setup-ssl.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "צריך sudo"; exit 1; }
DOMAIN=satview.ddns.net

apt-get update
apt-get install -y certbot python3-certbot-nginx

# certbot needs an nginx server block on port 80 for this domain
cat > /etc/nginx/sites-available/bondcam-ssl <<EOF
server {
    listen 80;
    server_name ${DOMAIN};
    auth_basic "BondCam Control Room";
    auth_basic_user_file /etc/nginx/.bondcam-htpasswd;
    root /var/www/bondcam-admin;
    index index.html;
    location / { try_files \$uri \$uri/ =404; }
    location /api/ { proxy_pass http://127.0.0.1:9997/; }
    location /hls/ { proxy_pass http://127.0.0.1:8888/; proxy_buffering off; }
    location /recordings/ { alias /var/recordings/; autoindex on; }
}
EOF
ln -sf /etc/nginx/sites-available/bondcam-ssl /etc/nginx/sites-enabled/bondcam-ssl
nginx -t && systemctl restart nginx

certbot --nginx -d ${DOMAIN} --non-interactive --agree-tos --register-unsafely-without-email --redirect

echo ""
echo "HTTPS מוכן:  https://${DOMAIN}/"
echo "ודא שפורט 80 ו-443 פתוחים אצל ספק ה-VPS."
