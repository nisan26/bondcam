#!/usr/bin/env bash
# =============================================================
# התקנת שרת בונדינג על Ubuntu 24 (satview.ddns.net)
# מתקין: srtla_rec (קבלת בונדינג) + srt-live-transmit + MediaMTX
# הרצה: sudo bash install.sh
# =============================================================
set -euo pipefail

[ "$(id -u)" -eq 0 ] || { echo "צריך להריץ עם sudo"; exit 1; }

SRTLA_PORT=5000      # פורט הבונדינג - הטלפון שולח לכאן (UDP)
RELAY_PORT=5002      # פנימי: srtla_rec -> srt-live-transmit
SRT_PORT=8890        # SRT צפייה/כניסה ב-MediaMTX (UDP)
HLS_PORT=8888        # צפייה בדפדפן (TCP)
RTMP_PORT=1935       # RTMP (TCP)

echo "== מתקין תלויות =="
apt-get update
apt-get install -y build-essential git curl tar libssl-dev srt-tools

echo "== בונה srtla (BELABOX) =="
rm -rf /opt/srtla-src
git clone https://github.com/BELABOX/srtla.git /opt/srtla-src
make -C /opt/srtla-src
install -m 755 /opt/srtla-src/srtla_rec /usr/local/bin/srtla_rec

echo "== מתקין MediaMTX =="
ARCH=amd64; [ "$(uname -m)" = "aarch64" ] && ARCH=arm64
VER=$(curl -fsSLI -o /dev/null -w '%{url_effective}' https://github.com/bluenviron/mediamtx/releases/latest | sed 's#.*/##')
echo "MediaMTX version: ${VER}"
curl -fsSL -o /tmp/mediamtx.tar.gz \
  "https://github.com/bluenviron/mediamtx/releases/download/${VER}/mediamtx_${VER}_linux_${ARCH}.tar.gz"
mkdir -p /opt/mediamtx
tar -xzf /tmp/mediamtx.tar.gz -C /opt/mediamtx

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
if [ -f "$SCRIPT_DIR/mediamtx.yml" ]; then
  cp "$SCRIPT_DIR/mediamtx.yml" /opt/mediamtx/mediamtx.yml
fi

echo "== יוצר שירותי systemd =="
cat > /etc/systemd/system/mediamtx.service <<EOF
[Unit]
Description=MediaMTX media server
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/opt/mediamtx/mediamtx /opt/mediamtx/mediamtx.yml
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF

# srt-live-transmit באמצע: חלון קליטה (lossmaxttl) שמאפשר לחבילות להגיע
# בסדר שונה משני הקישורים בלי לבקש שידור חוזר מיותר - קריטי לבונדינג איכותי
cat > /etc/systemd/system/bonding-relay.service <<EOF
[Unit]
Description=SRT relay with reorder tolerance (bonding)
After=mediamtx.service
Wants=mediamtx.service

[Service]
ExecStart=/usr/bin/srt-live-transmit "srt://127.0.0.1:${RELAY_PORT}?mode=listener&lossmaxttl=40&latency=2000" "srt://127.0.0.1:${SRT_PORT}?mode=caller&streamid=publish:live"
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/srtla.service <<EOF
[Unit]
Description=SRTLA bonding receiver
After=bonding-relay.service
Wants=bonding-relay.service

[Service]
ExecStart=/usr/local/bin/srtla_rec ${SRTLA_PORT} 127.0.0.1 ${RELAY_PORT}
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now mediamtx.service bonding-relay.service srtla.service

echo "== חומת אש =="
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow ${SRTLA_PORT}/udp
  ufw allow ${SRT_PORT}/udp
  ufw allow ${HLS_PORT}/tcp
  ufw allow ${RTMP_PORT}/tcp
  echo "פורטים נפתחו ב-ufw"
else
  echo "ufw לא פעיל - ודא שהפורטים ${SRTLA_PORT}/udp, ${SRT_PORT}/udp, ${HLS_PORT}/tcp פתוחים אצל ספק ה-VPS"
fi

echo ""
echo "============================================="
echo "  ההתקנה הסתיימה!"
echo "  בונדינג מהטלפון:  srtla://satview.ddns.net:${SRTLA_PORT}"
echo "  צפייה ב-VLC:      srt://satview.ddns.net:${SRT_PORT}?streamid=read:live"
echo "  צפייה בדפדפן:     http://satview.ddns.net:${HLS_PORT}/live"
echo "  סטטוס:            systemctl status srtla bonding-relay mediamtx"
echo "============================================="
