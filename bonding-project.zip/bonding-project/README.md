# מערכת בונדינג לשידור חי - סלולר + WiFi

שידור SRT יציב "ברמת טלוויזיה": הטלפון מפצל את הווידאו על שתי רשתות במקביל, והשרת שלך (satview.ddns.net) מאחד אותן בחזרה.

## ארכיטקטורה

```
טלפון: מצלמה+מיקרופון → SRT → מפצל SRTLA ──סלולר──┐
                                          └──WiFi────┤ שרת satview.ddns.net:
                                                     └→ srtla_rec (5000) → srt-live-transmit (איחוי וסידור מחדש)
                                                        → MediaMTX (8890) → צפייה / הקלטה / יוטיוב
```

הפרוטוקול: **SRTLA** (של BELABOX) - הסטנדרט בעולם שידורי ה-IRL המקצועיים. כל חבילה נשלחת דרך הקישור הכי טוב באותו רגע; קישור שנחלש מקבל פחות תעבורה אוטומטית.

---

## 1. התקנת השרת (Ubuntu 24)

```bash
scp -r server/ user@satview.ddns.net:~/bonding-server
ssh user@satview.ddns.net
cd ~/bonding-server
sudo bash install.sh
```

הסקריפט מתקין ומפעיל כשירותי systemd:
- **srtla_rec** - מקבל את הבונדינג בפורט **5000/UDP**
- **bonding-relay** (srt-live-transmit) - סובלנות לחבילות שמגיעות בסדר שונה משני הקישורים (`lossmaxttl=40`, `latency=2000`) - קריטי לאיכות הבונדינג
- **MediaMTX** - שרת SRT בפורט **8890/UDP**, צפייה בדפדפן בפורט **8888**

בדיקה: `systemctl status srtla bonding-relay mediamtx`

**חשוב:** ודא שהפורטים 5000/UDP ו-8890/UDP פתוחים גם בפאנל של ספק ה-VPS (לא רק ufw).

---

## 2. אנדרואיד - אפליקציית BondCam (קוד מקור מלא)

תיקייה: `android/BondCam`

1. פתח את התיקייה ב-Android Studio (אם מוצע לתקן Gradle wrapper - אשר, גרסה 8.6+).
2. Build ‏→ APK, התקן בטלפון.
3. באפליקציה: כתובת `satview.ddns.net`, פורט `5000`, Stream ID‏ `publish:live` → **התחל שידור**.
4. ודא ש-WiFi וסלולר דלוקים שניהם. השורה הירוקה למטה מציגה את מצב שני הקישורים (win/fly).

מה יש בקוד:
- `MainActivity.kt` - מצלמה + מיקרופון + קידוד H.264/AAC ושידור SRT (ספריית RootEncoder)
- `srtla/SrtlaSender.kt` - מימוש מלא של פרוטוקול SRTLA בקוטלין: רישום מול השרת, פיצול חבילות לפי איכות קישור, ACK/NAK, keepalive, התאוששות מנפילת רשת
- `srtla/BondingNetworks.kt` - מכריח את אנדרואיד להחזיק סלולר + WiFi דלוקים במקביל וכובל סוקט לכל רשת

הערות:
- אם גרסת `RootEncoder:2.5.9` לא נמצאת ב-sync, עדכן למספר האחרון מ-github.com/pedroSG94/RootEncoder (יתכנו שינויי API קטנים).
- גרסה 1: השידור רץ כשהאפליקציה על המסך (המסך נשאר דלוק אוטומטית). אפשר להוסיף Foreground Service בהמשך.

## 3. אייפון

בניית אפליקציית iOS דורשת Mac + Xcode, לכן לאייפון הפתרון המעשי: **Moblin** (חינמית, קוד פתוח, נבנתה בדיוק לזה) - תומכת SRTLA באופן מובנה ועובדת עם אותו שרת בדיוק:

1. הורד **Moblin** מה-App Store.
2. Settings → Streams → הוסף זרם:
   - URL: `srtla://satview.ddns.net:5000`
   - Stream ID: לא חובה (השרת מקבל כל זרם)
3. Moblin מנהלת את הבונדינג סלולר+WiFi לבד.

(רוצה בכל זאת קוד מקור לאפליקציית iOS משלך? אפשר - תגיד ואכין פרויקט Swift.)

---

## 4. צפייה ושידור הלאה

| מה | איך |
|---|---|
| VLC / OBS (איכות מלאה, השהיה נמוכה) | `srt://satview.ddns.net:8890?streamid=read:live` |
| דפדפן | `http://satview.ddns.net:8888/live` |
| הקלטה בשרת | הסר `#` מסעיף record ב-`/opt/mediamtx/mediamtx.yml` והפעל מחדש: `systemctl restart mediamtx` |
| שידור ליוטיוב/טוויץ' | הסר `#` מסעיף runOnReady ב-mediamtx.yml, מלא Stream Key, והתקן ffmpeg: `apt install ffmpeg` |

## 5. כוונון ליציבות מקסימלית

- **ביטרייט:** התחל ב-4500 Kbps ל-1080p. אם יש קפיאות - הורד ל-3000.
- **השהיית SRT (latency):** לבונדינג מומלץ 2000-4000ms. ב-Moblin זה בהגדרות הזרם; באפליקציית BondCam אפשר להוסיף `&latency=3000` ל-URL אם גרסת הספרייה תומכת.
- **בדיקת בונדינג:** התחל שידור, כבה WiFi - השידור צריך להמשיך על סלולר בלי להתנתק (אחרי ריצוד קצר).
- לוגים בשרת: `journalctl -u srtla -f`
