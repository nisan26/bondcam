package com.satview.bondcam.srtla

import android.net.Network
import android.util.Log
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.security.SecureRandom

/**
 * לב הבונדינג בצד הטלפון (תואם ל-srtla_rec של BELABOX בשרת).
 *
 * איך זה עובד:
 *   ספריית ה-SRT (המצלמה/מיקרופון) שולחת אל 127.0.0.1:localPort.
 *   אנחנו מפצלים את החבילות בין כמה חיבורי UDP - אחד כבול ל-WiFi
 *   ואחד לרשת הסלולרית - לפי איכות כל קישור (חלון/ACK/NAK).
 *   srtla_rec בשרת מאחד הכל בחזרה לזרם SRT אחד.
 */
class SrtlaSender(
    private val localPort: Int,
    private val serverHost: String,
    private val serverPort: Int,
    private val onStatus: (String) -> Unit
) {
    companion object { private const val TAG = "SrtlaSender" }

    private val lock = Any()
    private val conns = LinkedHashMap<String, SrtlaConnection>() // key: שם רשת
    private var serverAddr: InetSocketAddress? = null
    private val pendingNetworks = LinkedHashMap<String, Network?>()

    // מזהה קבוצת SRTLA: אנחנו שולחים REG1 עם חצי אקראי, השרת מחזיר REG2 עם מזהה מלא
    private val reg1Id = ByteArray(SrtlaProto.ID_LEN).also { SecureRandom().nextBytes(it) }
    @Volatile private var groupId: ByteArray? = null
    @Volatile private var lastReg1Ms = 0L

    private var localSocket: DatagramSocket? = null
    @Volatile private var localPeer: SocketAddress? = null
    @Volatile private var running = false

    fun start() {
        running = true
        Thread({
            // פתיחת סוקט מקומי שאליו מתחברת ספריית ה-SRT
            val sock = DatagramSocket(InetSocketAddress(InetAddress.getLoopbackAddress(), localPort))
            localSocket = sock

            // פתרון DNS של השרת (עם נסיונות חוזרים - DDNS)
            while (running && serverAddr == null) {
                try {
                    serverAddr = InetSocketAddress(InetAddress.getByName(serverHost), serverPort)
                    onStatus("שרת: $serverHost")
                } catch (e: Exception) {
                    onStatus("שגיאת DNS ל-$serverHost, מנסה שוב...")
                    Thread.sleep(2000)
                }
            }
            if (!running) return@Thread

            // רשתות שהתווספו לפני שה-DNS הסתיים
            synchronized(lock) {
                for ((name, net) in pendingNetworks) createConn(name, net)
                pendingNetworks.clear()
            }

            Thread({ housekeepingLoop() }, "srtla-housekeeping").start()
            localLoop(sock)
        }, "srtla-local").start()
    }

    fun stop() {
        running = false
        synchronized(lock) {
            for (c in conns.values) c.close()
            conns.clear()
        }
        try { localSocket?.close() } catch (_: Exception) {}
    }

    // ---------- ניהול רשתות (נקרא מ-BondingNetworks) ----------

    fun addNetwork(name: String, network: Network?) {
        synchronized(lock) {
            if (serverAddr == null) { pendingNetworks[name] = network; return }
            createConn(name, network)
        }
    }

    fun removeNetwork(name: String) {
        synchronized(lock) {
            conns.remove(name)?.close()
        }
        onStatus("רשת נותקה: $name")
    }

    private fun createConn(name: String, network: Network?) {
        conns.remove(name)?.close()
        val addr = serverAddr ?: return
        try {
            val conn = SrtlaConnection(name, network, addr)
            conns[name] = conn
            Thread({ connReceiveLoop(conn) }, "srtla-rx-$name").start()
            // אם כבר יש לנו מזהה קבוצה - נרשום את החיבור החדש מיד
            val id = groupId
            if (id != null) sendReg2(conn, id)
            onStatus("רשת נוספה: $name")
        } catch (e: Exception) {
            Log.e(TAG, "createConn $name failed", e)
        }
    }

    // ---------- נתיב השליחה: SRT מקומי -> פיצול לקישורים ----------

    private fun localLoop(sock: DatagramSocket) {
        val buf = ByteArray(SrtlaProto.MTU)
        while (running) {
            try {
                val pkt = DatagramPacket(buf, buf.size)
                sock.receive(pkt)
                localPeer = pkt.socketAddress
                val len = pkt.length
                synchronized(lock) {
                    val conn = selectConn() ?: return@synchronized
                    if (SrtlaProto.isSrtData(buf, len)) {
                        conn.inFlight.add(SrtlaProto.dataSeq(buf))
                        if (conn.inFlight.size > 10000) conn.inFlight.clear() // הגנה
                    }
                    conn.send(buf, len)
                }
            } catch (e: Exception) {
                if (running) Log.w(TAG, "localLoop: ${e.message}")
            }
        }
    }

    /** בחירת הקישור הטוב ביותר: חלון גדול וחבילות "באוויר" מעטות */
    private fun selectConn(): SrtlaConnection? {
        var best: SrtlaConnection? = null
        var bestScore = -1
        for (c in conns.values) {
            val s = c.score()
            if (s > bestScore) { bestScore = s; best = c }
        }
        return best
    }

    // ---------- נתיב הקבלה: שרת -> טיפול בבקרה + החזרה ל-SRT מקומי ----------

    private fun connReceiveLoop(conn: SrtlaConnection) {
        val buf = ByteArray(SrtlaProto.MTU)
        while (running && !conn.closed) {
            try {
                val pkt = DatagramPacket(buf, buf.size)
                conn.socket.receive(pkt)
                conn.lastReceivedMs = System.currentTimeMillis()
                val len = pkt.length
                when (val type = SrtlaProto.packetType(buf, len)) {
                    SrtlaProto.TYPE_ACK -> handleSrtlaAck(conn, buf, len)
                    SrtlaProto.TYPE_KEEPALIVE -> { /* עדכנו lastReceivedMs, זה מספיק */ }
                    SrtlaProto.TYPE_REG2 -> {
                        if (len >= 2 + SrtlaProto.ID_LEN && groupId == null) {
                            groupId = buf.copyOfRange(2, 2 + SrtlaProto.ID_LEN)
                            Log.i(TAG, "קיבלנו מזהה קבוצה, רושמים את כל הקישורים")
                            synchronized(lock) {
                                for (c in conns.values) sendReg2(c, groupId!!)
                            }
                        }
                    }
                    SrtlaProto.TYPE_REG3 -> {
                        if (!conn.registered) {
                            conn.registered = true
                            onStatus("קישור פעיל: ${conn.name}")
                        }
                    }
                    SrtlaProto.TYPE_REG_NGP -> { groupId = null } // השרת אותחל - רישום מחדש
                    SrtlaProto.TYPE_REG_ERR, SrtlaProto.TYPE_REG_NAK -> {
                        Log.w(TAG, "שגיאת רישום SRTLA (${Integer.toHexString(type)})")
                    }
                    else -> {
                        // חבילת SRT רגילה מהשרת
                        if (type == SrtlaProto.SRT_TYPE_ACK && len >= 20) handleSrtAck(buf)
                        if (type == SrtlaProto.SRT_TYPE_NAK && len >= 20) handleSrtNak(buf, len)
                        forwardToLocal(buf, len)
                    }
                }
            } catch (e: Exception) {
                if (running && !conn.closed) Log.w(TAG, "rx ${conn.name}: ${e.message}")
            }
        }
    }

    private fun forwardToLocal(buf: ByteArray, len: Int) {
        val peer = localPeer ?: return
        try { localSocket?.send(DatagramPacket(buf, len, peer)) } catch (_: Exception) {}
    }

    /** ACK של SRTLA: רשימת seq שהתקבלו בקישור הזה - משפר את החלון שלו */
    private fun handleSrtlaAck(conn: SrtlaConnection, buf: ByteArray, len: Int) {
        synchronized(lock) {
            var off = 4
            while (off + 4 <= len) {
                val seq = SrtlaProto.int32At(buf, off) and 0x7FFFFFFF
                if (conn.inFlight.remove(seq)) {
                    conn.window = minOf(conn.window + SrtlaProto.WINDOW_INCR, SrtlaProto.WINDOW_MAX)
                }
                off += 4
            }
        }
    }

    /** ACK של SRT מהשרת: כל מה שלפני המספר הזה התקבל - מנקים מכל הקישורים */
    private fun handleSrtAck(buf: ByteArray) {
        val lastAck = SrtlaProto.int32At(buf, 16) and 0x7FFFFFFF
        synchronized(lock) {
            for (c in conns.values) {
                c.inFlight.removeAll { seq -> SrtlaProto.seqBefore(seq, lastAck) }
            }
        }
    }

    /** NAK של SRT: חבילות אבדו - מקטינים את חלון הקישור שאיבד אותן */
    private fun handleSrtNak(buf: ByteArray, len: Int) {
        synchronized(lock) {
            var off = 16
            while (off + 4 <= len) {
                val v = SrtlaProto.int32At(buf, off)
                if (v < 0) {
                    // טווח: מ-(v בלי ה-MSB) עד הערך הבא
                    val start = v and 0x7FFFFFFF
                    off += 4
                    if (off + 4 > len) break
                    val end = SrtlaProto.int32At(buf, off) and 0x7FFFFFFF
                    var s = start
                    var guard = 0
                    while (guard < 2000) {
                        penalizeLoss(s)
                        if (s == end) break
                        s = (s + 1) and 0x7FFFFFFF
                        guard++
                    }
                } else {
                    penalizeLoss(v and 0x7FFFFFFF)
                }
                off += 4
            }
        }
    }

    private fun penalizeLoss(seq: Int) {
        for (c in conns.values) {
            if (c.inFlight.remove(seq)) {
                c.window = maxOf(c.window - SrtlaProto.WINDOW_DECR, SrtlaProto.WINDOW_MIN)
                return
            }
        }
    }

    // ---------- רישום ותחזוקה ----------

    private fun sendReg1(conn: SrtlaConnection) {
        conn.send(SrtlaProto.buildControl(SrtlaProto.TYPE_REG1, reg1Id), 2 + SrtlaProto.ID_LEN)
    }

    private fun sendReg2(conn: SrtlaConnection, id: ByteArray) {
        conn.lastRegSentMs = System.currentTimeMillis()
        conn.send(SrtlaProto.buildControl(SrtlaProto.TYPE_REG2, id), 2 + SrtlaProto.ID_LEN)
    }

    private fun housekeepingLoop() {
        val keepalive = SrtlaProto.buildControl(SrtlaProto.TYPE_KEEPALIVE)
        while (running) {
            try {
                val now = System.currentTimeMillis()
                synchronized(lock) {
                    // שלב 1: השגת מזהה קבוצה מהשרת
                    if (groupId == null && conns.isNotEmpty() && now - lastReg1Ms > SrtlaProto.REG_RETRY_MS) {
                        lastReg1Ms = now
                        sendReg1(conns.values.first())
                    }
                    for (c in conns.values) {
                        // keepalive קבוע לכל קישור
                        if (now - c.lastKeepaliveMs > SrtlaProto.KEEPALIVE_INTERVAL_MS) {
                            c.lastKeepaliveMs = now
                            c.send(keepalive, keepalive.size)
                        }
                        // קישור שהפסיק להגיב - מבטלים רישום וננסה שוב
                        if (c.registered && now - c.lastReceivedMs > SrtlaProto.CONN_TIMEOUT_MS) {
                            c.registered = false
                            c.inFlight.clear()
                            c.window = SrtlaProto.WINDOW_MIN * 2
                            onStatus("קישור איטי/נפל: ${c.name}")
                        }
                        // רישום מחדש של קישור לא רשום
                        val id = groupId
                        if (!c.registered && id != null && now - c.lastRegSentMs > SrtlaProto.REG_RETRY_MS) {
                            sendReg2(c, id)
                        }
                        // התאוששות איטית של החלון
                        c.window = minOf(c.window + 1, SrtlaProto.WINDOW_MAX)
                    }
                }
                Thread.sleep(200)
            } catch (e: InterruptedException) {
                return
            } catch (e: Exception) {
                Log.w(TAG, "housekeeping: ${e.message}")
            }
        }
    }

    /** כמה קישורים רשומים כרגע (לשימוש לפני פתיחת ה-SRT) */
    fun registeredCount(): Int = synchronized(lock) { conns.values.count { it.registered } }

    /** סטטוס קצר לתצוגה */
    fun statusLine(): String = synchronized(lock) {
        conns.values.joi