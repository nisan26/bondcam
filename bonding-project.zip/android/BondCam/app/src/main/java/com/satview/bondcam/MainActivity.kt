package com.satview.bondcam

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.SurfaceHolder
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pedro.common.ConnectChecker
import com.pedro.library.srt.SrtCamera2
import com.pedro.library.view.OpenGlView
import com.satview.bondcam.srtla.BondingNetworks
import com.satview.bondcam.srtla.SrtlaSender

class MainActivity : AppCompatActivity(), ConnectChecker, SurfaceHolder.Callback {

    companion object {
        private const val LOCAL_SRT_PORT = 6000 // הפורט המקומי שדרכו עובר הבונדינג
    }

    private lateinit var openGlView: OpenGlView
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView
    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var etBitrate: EditText
    private lateinit var etStreamId: EditText

    private var camera: SrtCamera2? = null
    private var sender: SrtlaSender? = null
    private var networks: BondingNetworks? = null
    private var streaming = false
    @Volatile private var srtStarted = false

    private val ui = Handler(Looper.getMainLooper())
    private val statusTicker = object : Runnable {
        override fun run() {
            sender?.let { tvStatus.text = it.statusLine() }
            ui.postDelayed(this, 1000)
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants.values.all { it }) initCamera()
            else Toast.makeText(this, "חייבים הרשאת מצלמה ומיקרופון", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        openGlView = findViewById(R.id.openGlView)
        btnStart = findViewById(R.id.btnStart)
        tvStatus = findViewById(R.id.tvStatus)
        etHost = findViewById(R.id.etHost)
        etPort = findViewById(R.id.etPort)
        etBitrate = findViewById(R.id.etBitrate)
        etStreamId = findViewById(R.id.etStreamId)

        openGlView.holder.addCallback(this)
        btnStart.setOnClickListener { if (streaming) stopAll() else startAll() }

        if (hasPermissions()) initCamera()
        else permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun hasPermissions() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun initCamera() {
        if (camera == null) camera = SrtCamera2(openGlView, this)
    }

    private fun startAll() {
        val cam = camera ?: return
        val host = etHost.text.toString().trim()
        val port = etPort.text.toString().trim().toIntOrNull() ?: 5000
        val bitrateKbps = etBitrate.text.toString().trim().toIntOrNull() ?: 4500
        val streamId = etStreamId.text.toString().trim().ifEmpty { "publish:live" }

        // 1. מכינים את המצלמה/מיקרופון מראש (לפני שנפתח SRT)
        val ok = cam.prepareVideo(1920, 1080, 30, bitrateKbps * 1024, 2, 0) &&
                 cam.prepareAudio(128 * 1024, 48000, true)
        if (!ok) {
            Toast.makeText(this, "המכשיר לא תומך בהגדרות הקידוד", Toast.LENGTH_LONG).show()
            return
        }

        // 2. בונדינג: מרימים את מנוע ה-SRTLA + שתי הרשתות
        sender = SrtlaSender(LOCAL_SRT_PORT, host, port) { msg ->
            runOnUiThread { if (!srtStarted) tvStatus.text = msg }
        }.also { it.start() }

        networks = BondingNetworks(this) { name, network, available ->
            if (available) sender?.addNetwork(name, network)
            else sender?.removeNetwork(name)
        }.also { it.start() }

        streaming = true
        srtStarted = false
        btnStart.text = getString(R.string.stop)
        setInputsEnabled(false)
        tvStatus.text = "ממתין לבונדינג..."

        // 3. פותחים SRT רק אחרי שלפחות קישור אחד נרשם לשרת.
        //    אחרת מנוע ה-SRT מתחיל לפני שהמנהרה מוכנה ונכשל ב-"Channel was closed".
        Thread({
            val deadline = System.currentTimeMillis() + 20000
            while (streaming && System.currentTimeMillis() < deadline) {
                if ((sender?.registeredCount() ?: 0) > 0) break
                try { Thread.sleep(200) } catch (_: InterruptedException) { return@Thread }
            }
            // חסד קצר כדי לוודא שהמנהרה יציבה
            try { Thread.sleep(600) } catch (_: InterruptedException) { return@Thread }
            if (!streaming) return@Thread
            runOnUiThread {
                if (!streaming) return@runOnUiThread
                srtStarted = true
                cam.streamClient.setReTries(1000) // חיבור מחדש אוטומטי
                cam.startStream("srt://127.0.0.1:$LOCAL_SRT_PORT?streamid=$streamId")
                ui.post(statusTicker)
            }
        }, "wait-srtla").start()
    }

    private fun stopAll() {
        ui.removeCallbacks(statusTicker)
        try { camera?.stopStream() } catch (_: Exception) {}
        networks?.stop(); networks = null
        sender?.stop(); sender = null
        streaming = false
        srtStarted = false
        btnStart.text = getString(R.string.start)
        setInputsEnabled(true)
        tvStatus.text = "נעצר"
    }

    private fun setInputsEnabled(enabled: Boolean) {
        etHost.isEnabled = enabled
        etPort.isEnabled = enabled
        etBitrate.isEnabled = enabled
        etStreamId.isEnabled = enabled
    }

    // ---------- תצוגה מקדימה ----------

    override fun surfaceCreated(holder: SurfaceHolder) {}

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (hasPermissions()) {
            initCamera()
            came